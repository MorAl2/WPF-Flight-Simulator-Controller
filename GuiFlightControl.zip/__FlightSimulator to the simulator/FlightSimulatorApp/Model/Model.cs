﻿using System;
using System.ComponentModel;
using System.Net.Sockets;
using System.Threading;
using System.Windows;
using System.Collections;

namespace GUI_Flight_Simulator_Controller.controlers
{
    public class Model : INotifyPropertyChanged
    {

        // socket for connecting to the simulator.
        private volatile TcpClient tcpClient = null;
        // socket stream
        private NetworkStream networkStream = null;
        // the observers list.
        public event PropertyChangedEventHandler PropertyChanged;
        // the method that will run when notification need to be sent.
        public void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        private string mapErrorText = String.Empty;
        private string simThrottle;
        private string simElevator;
        private string simRudder;
        private string simAileron;
        // for stooping the threads.
        private volatile Boolean stop = false;
        private volatile Boolean tryToConnect = false;
        private volatile Queue joystickQueue;
        // all the plane fields
        private string heading = "Uninitialized";
        private string verticalSpeed = "Uninitialized";
        private string groundSpeed = "Uninitialized";
        private string airSpeed = "Uninitialized";
        private string gpsAlt = "Uninitialized";
        private string roll = "Uninitialized";
        private string pitch = "Uninitialized";
        private string altitude = "Uninitialized";
        private string ipStr;
        private int portNum;
        private System.Windows.Visibility errorMsg = System.Windows.Visibility.Hidden;
        private System.Windows.Visibility errorMsgTime = System.Windows.Visibility.Hidden;
        private System.Windows.Visibility errorMsgDouble = System.Windows.Visibility.Hidden;
        private Microsoft.Maps.MapControl.WPF.Location location = new Microsoft.Maps.MapControl.WPF.Location(20.1, 23.9);
        private Microsoft.Maps.MapControl.WPF.Location maplocation = new Microsoft.Maps.MapControl.WPF.Location(20.1, 23.9);
        private Visibility connectedSign = Visibility.Visible;
        private Visibility badConnect = Visibility.Hidden;

        // properties of the simulator fields.
        public Microsoft.Maps.MapControl.WPF.Location Location { get { return this.location; } set { if (value != this.location) { this.location = value; OnPropertyChanged("Location"); } } }
        public Microsoft.Maps.MapControl.WPF.Location MapLocation { get { return this.maplocation; } set { if (value != this.maplocation) { this.maplocation = value; OnPropertyChanged("MapLocation"); } } }
        public string Heading { get { return this.heading; } set { if (value != this.heading) { this.heading = value; OnPropertyChanged("Heading"); } } }
        public string VerticalSpeed { get { return this.verticalSpeed; } set { if (value != this.verticalSpeed) { this.verticalSpeed = value; OnPropertyChanged("VerticalSpeed"); } } }
        public string GroundSpeed { get { return this.groundSpeed; } set { if (value != this.groundSpeed) { this.groundSpeed = value; OnPropertyChanged("GroundSpeed"); } } }
        public string AirSpeed { get { return this.airSpeed; } set { if (value != this.airSpeed) { this.airSpeed = value; OnPropertyChanged("AirSpeed"); } } }
        public string GpsAlt { get { return this.gpsAlt; } set { if (value != this.gpsAlt) { this.gpsAlt = value; OnPropertyChanged("GpsAlt"); } } }
        public string Roll { get { return this.roll; } set { if (value != this.roll) { this.roll = value; OnPropertyChanged("Roll"); } } }
        public string Pitch { get { return this.pitch; } set { if (value != this.pitch) { this.pitch = value; OnPropertyChanged("Pitch"); } } }
        public string Altitude { get { return this.altitude; } set { if (value != this.altitude) { this.altitude = value; OnPropertyChanged("Altitude"); } } }
        public string MapErrorText { get { return this.mapErrorText; } set { if (value != this.mapErrorText) { this.mapErrorText = value; OnPropertyChanged("MapErrorText"); } } }
        public System.Windows.Visibility ErrorMsg { get { return this.errorMsg; } set { if (value != this.errorMsg) { this.errorMsg = value; OnPropertyChanged("ErrorMsg"); } } }
        public System.Windows.Visibility ErrorMsgTime { get { return this.errorMsgTime; } set { if (value != this.errorMsgTime) { this.errorMsgTime = value; OnPropertyChanged("ErrorMsgTime"); } } }
        public System.Windows.Visibility ErrorMsgDouble { get { return this.errorMsgDouble; } set { if (value != this.errorMsgDouble) { this.errorMsgDouble = value; OnPropertyChanged("ErrorMsgDouble"); } } }
        public System.Windows.Visibility ConnectedSign { get { return this.connectedSign; } set { if (value != this.connectedSign) { this.connectedSign = value; OnPropertyChanged("ConnectedSign"); } } }
        public System.Windows.Visibility BadConnect { get { return this.badConnect; } set { if (value != this.badConnect) { this.badConnect = value; OnPropertyChanged("BadConnect"); } } }
        public string Aileron{ get { return simAileron; } set { simAileron = "set /controls/flight/aileron " + value + " \n"; } }
        public string Rudder { get { return simRudder; } set { simRudder = "set /controls/flight/rudder " + value + " \n"; } }
        public string Elevator{ get { return simElevator; }set { simElevator = "set /controls/flight/elevator " + value + " \n"; } }
        public string Throttle{ get { return simThrottle; } set { simThrottle = "set /controls/engines/current-engine/throttle " + value + " \n"; } }

        // connecting to the simulator.
        public void Connect(string ip, int port)
        {
            this.ipStr = ip;
            this.portNum = port;
            Thread thr = new Thread(ThreadedConnect);
            this.tryToConnect = true;
            thr.Start();
        }
        // the threaded connection to the server
        public void ThreadedConnect()
        {
            lock (this)
            {
                this.stop = true;
                TcpClient tcpclnt = new TcpClient();
                Console.WriteLine("Trying To Connect..");
                try
                {
                    if(this.tryToConnect == true)
                    {
                        tcpclnt.Connect(this.ipStr, this.portNum);
                        if (tcpclnt.Connected)
                        {
                            Console.WriteLine("Connected");
                            this.joystickQueue = new Queue();
                            this.tcpClient = tcpclnt;
                            this.stop = false;
                            this.networkStream = tcpclnt.GetStream();
                            OnPropertyChanged("Connected");
                            this.ConnectedSign = Visibility.Hidden;
                            this.ErrorMsg = Visibility.Hidden;
                            this.ErrorMsgTime = Visibility.Hidden;
                            this.MapErrorText = "";
                            this.ErrorMsgDouble = Visibility.Hidden;
                            UpdateGaugeScreen();
                            UpdateMapScreen();
                            UpdateControllerScreen();
                        }
                    }
                }
                catch (Exception)
                {
                    if(this.tryToConnect== true)
                    {
                        this.BadConnect = Visibility.Visible;
                    }
                }
            }
        }

        // updating the gauge board.
        public void UpdateGaugeScreen()
        {
            try
            {
                // checking if the connection still exist.
                if (tcpClient == null || networkStream == null)
                {
                    throw new Exception();
                }
                if (tcpClient.Connected == false)
                {
                    throw new Exception();
                }
                // running the thread.
                Thread thr = new Thread(GaugeUpdateThreaded);
                thr.Start();
            }
            catch
            {
                Thread t = new Thread(ErrorSignal);
                t.Start();
            }
        }
        // updating the plane location on the map.
        public void UpdateMapScreen()
        {
            try
            {
                // checking if the connection still exist.
                if (tcpClient == null || networkStream == null)
                {
                    return;
                }
                if (tcpClient.Connected == false)
                {
                    throw new Exception();
                }
                // running the thread.
                Thread thr = new Thread(MapUpdateThreaded);
                thr.Start();
            }
            catch (Exception)
            {
                Thread t = new Thread(ErrorSignal);
                t.Start();
            }

        }
        // the functuon that will run in the background and update the gauge board.
        public void GaugeUpdateThreaded()
        {
            // variable for result if error occourd
            bool errorFlag;
            String temp;
            double tempDouble;
            while (!stop)
            {
                try
                {
                    // getting the information from the simulator and updating the values, checking if valid as well..
                    errorFlag = false;
                    temp = SendAndRcv("get /instrumentation/heading-indicator/indicated-heading-deg\n");
                    if (Double.TryParse(temp, out tempDouble))
                        this.Heading = temp.Length != 0 ? temp : this.Heading;
                    else errorFlag = true;
                    temp = SendAndRcv("get /instrumentation/gps/indicated-vertical-speed\n");
                    if (Double.TryParse(temp, out tempDouble))
                        this.VerticalSpeed = temp.Length != 0 ? temp : this.VerticalSpeed;
                    else errorFlag = true;
                    temp = SendAndRcv("get /instrumentation/gps/indicated-ground-speed-kt\n");
                    if (Double.TryParse(temp, out tempDouble))
                        this.GroundSpeed = temp.Length != 0 ? temp : this.GroundSpeed;
                    else errorFlag = true;
                    temp = SendAndRcv("get /instrumentation/airspeed-indicator/indicated-speed-kt\n");
                    if (Double.TryParse(temp, out tempDouble))
                        this.AirSpeed = temp.Length != 0 ? temp : this.AirSpeed;
                    else errorFlag = true;
                    temp = SendAndRcv("get /instrumentation/gps/indicated-altitude-ft\n");
                    if (Double.TryParse(temp, out tempDouble))
                        this.GpsAlt = temp.Length != 0 ? temp : this.GpsAlt;
                    else errorFlag = true;
                    temp = SendAndRcv("get /instrumentation/attitude-indicator/internal-roll-deg\n");
                    if (Double.TryParse(temp, out tempDouble))
                        this.Roll = temp.Length != 0 ? temp : this.Roll;
                    else errorFlag = true;
                    temp = SendAndRcv("get /instrumentation/attitude-indicator/internal-pitch-deg\n");
                    if (Double.TryParse(temp, out tempDouble))
                        this.Pitch = temp.Length != 0 ? temp : this.Pitch;
                    else errorFlag = true;
                    temp = SendAndRcv("get /instrumentation/altimeter/indicated-altitude-ft\n");
                    if (Double.TryParse(temp, out tempDouble))
                        this.Altitude = temp.Length != 0 ? temp : this.Altitude;
                    else errorFlag = true;
                    // update property for show or hidden error messge
                    this.ErrorMsgDouble = errorFlag ? Visibility.Visible: Visibility.Hidden;
                    if(tcpClient == null)
                    {
                        throw new Exception();
                    }
                    else if (tcpClient.Connected == false)
                    {
                        this.MapErrorText = "Connection To Server Was Severed, if it dosen't resume after few seconds Please Disconnect and Connect Again";
                        throw new Exception();
                    }
                    Thread.Sleep(250);
                }
                catch (Exception)
                {
                    Thread t = new Thread(ErrorSignal);
                    t.Start();
                }
            }
        }
        // the functuon that will run in the background and update the gauge board.
        public void MapUpdateThreaded()
        {
            bool isFirst = true;
            while (!stop)
            {
                try
                {
                    string lon, len;
                    // geting the location points
                    lon = SendAndRcv("get /position/longitude-deg\n");
                    len = SendAndRcv("get /position/latitude-deg\n");
                    // checking for invalid data rcved
                    if(!Double.TryParse(lon, out _) || !Double.TryParse(len, out _))
                    {
                        this.MapErrorText = "Invalid Location Rcved or server was disconnected, If the values dosen't update after few second please Connect again";
                    }
                    if (lon.Length != 0 && len.Length != 0)
                    {
                        double lend = double.Parse(len);
                        double lond = double.Parse(lon);
                        // setting the new location.
                        if (lend <= 90 && lend >= -90 || lond <= 180 && lond >= -180)
                        {
                            this.MapErrorText = "";
                            this.Location = new Microsoft.Maps.MapControl.WPF.Location(lend, lond);
                            if (isFirst)
                            {
                                // in the first time putting the map where the plane is.
                                isFirst = false;
                                this.MapLocation = new Microsoft.Maps.MapControl.WPF.Location(lend, lond);
                            }
                        }
                        else
                        {
                            this.MapErrorText = "Location Rcved Is Out Of Bounds";
                        }
                        if(tcpClient.Connected == false)
                        {
                            this.MapErrorText = "Connection To Server Was Severed, Please Exit and Connect Again";
                            throw new Exception();
                        }
                    }
                    Thread.Sleep(250);
                }
                catch (Exception)
                {
                    Thread t = new Thread(ErrorSignal);
                    t.Start();
                }

            }
        }

        // method for sending and rcving data from the simulator
        public string SendAndRcv(string sendMsg)
        {
            // making sure just 1 thread will use this each time.
            lock (this)
            {
                try
                {
                    if (this.tcpClient != null && this.networkStream != null) { 
                        // sending the msg in bytes.
                        Byte[] msg = System.Text.Encoding.ASCII.GetBytes(sendMsg);
                        this.networkStream.Write(msg, 0, msg.Length);

                        // getting the response.
                        msg = new Byte[1024];
                        this.networkStream.ReadTimeout = 10000;
                        int res;
                        try
                        {
                            res = this.networkStream.Read(msg, 0, 1024);
                        }
                        catch (InvalidOperationException)
                        {
                            // telling tell timeout accourd.
                            res = -1;
                        }
                        if (res == -1)
                        {
                            this.ErrorMsgTime = Visibility.Visible;
                        }
                        else
                        {
                            this.ErrorMsgTime = Visibility.Hidden;
                        }
                        String responseMsg = String.Empty;
                        responseMsg = System.Text.Encoding.ASCII.GetString(msg, 0, res);
                        // checking for bad response.
                        if (tcpClient.Connected == false)
                        {
                            this.MapErrorText = "Connection To Server Was Severed, Please Disconnect and Connect Again";
                            throw new Exception();
                        }
                        if (responseMsg.Equals("ERR") || res == 0)
                        {
                            return String.Empty;
                        }
                        return responseMsg;
                    }
                    else
                    {
                        throw new Exception();
                    }
                }
                catch (Exception)
                {
                    // letting the user know of the problem.
                    Thread t = new Thread(ErrorSignal);
                    t.Start();
                    return String.Empty;
                }
            }

        }

        // setting the msg to tell the user problem happend.
        public void ErrorSignal()
        {
            this.ErrorMsg = System.Windows.Visibility.Visible;
            this.stop = true;
        }

        // finishing the connection.
        public void Disconnect()
        {
            try
            {
                lock (this)
                {
                    tryToConnect = false;
                    this.stop = true;
                    Thread.Sleep(10);
                    this.ConnectedSign = Visibility.Visible;
                    Heading = "Uninitialized";
                    VerticalSpeed = "Uninitialized";
                    GroundSpeed = "Uninitialized";
                    AirSpeed = "Uninitialized";
                    GpsAlt = "Uninitialized";
                    Roll = "Uninitialized";
                    Pitch = "Uninitialized";
                    Altitude = "Uninitialized";
                    ErrorMsg = System.Windows.Visibility.Hidden;
                    Location = new Microsoft.Maps.MapControl.WPF.Location(20.1, 23.9);
                    MapLocation = new Microsoft.Maps.MapControl.WPF.Location(20.1, 23.9);
                    BadConnect = Visibility.Hidden;
                    this.ErrorMsgDouble = Visibility.Hidden;
                    this.MapErrorText = "";
                    if (this.tcpClient != null)
                    {
                        this.tcpClient.Close();
                    }
                }
            }
            catch(Exception)
            {

            }
        }
        /*
         * get value from view to send it to simulator 
         */
        public void MoveJoystickX(double rudder)
        {
            this.Rudder = rudder.ToString();
            if (this.tcpClient != null)
            {
                if (this.tcpClient.Connected)
                {
                    // add command to Q of commands for send to simulator
                    joystickQueue.Enqueue(this.Rudder);
                }
            }
        }
        /*
        * get value from view to send it to simulator 
        */
        public void MoveJoystickY(double elevator)
        {
            this.Elevator = elevator.ToString();
            if (this.tcpClient != null)
            {
                if (this.tcpClient.Connected)
                {
                    // add command to Q of commands for send to simulator
                    joystickQueue.Enqueue(this.Elevator);
                }
            }
        }
        /*
        * get value from view to send it to simulator 
        */
        public void MoveThrottle(double throttle)
        {
            this.Throttle = throttle.ToString();
            if (this.tcpClient != null)
            {
                if (this.tcpClient.Connected)
                {
                    // add command to Q of commands for send to simulator
                    joystickQueue.Enqueue(this.Throttle);
                }
            }
        }
        /*
        * get value from view to send it to simulator 
        */
        public void MoveAileron(double aileron)
        {
            this.Aileron = aileron.ToString();
            if (this.tcpClient != null)
            {
                if (this.tcpClient.Connected)
                {
                    // add command to Q of commands for send to simulator
                    joystickQueue.Enqueue(this.Aileron);
                }
            }
        }
        // the functuon that will run in the background and update the controller.
        public void UpdateControllerScreen()
        {
            try
            {
                // checking if the connection still exist.
                if (tcpClient == null || networkStream == null)
                {
                    throw new Exception();
                }
                if (tcpClient.Connected == false)
                {
                    throw new Exception();
                }
                // running the thread.
                Thread thr = new Thread(ControllerUpdateThreaded);
                thr.Start();
            }
            catch
            {
                Thread t = new Thread(ErrorSignal);
                t.Start();
            }
        }
        // the functuon that will run in the background and update the controller.
        public void ControllerUpdateThreaded()
        {
            while (!stop)
            {
                try
                {
                    // check if Q of commands is not empty 
                    while (!stop&& joystickQueue.Count != 0)
                    {
                        // send commands set to simulator
                        SendAndRcv((string)joystickQueue.Dequeue());
                    }
                    Thread.Sleep(100);
                }
                catch (Exception)
                {
                    Thread t = new Thread(ErrorSignal);
                    t.Start();
                }
            }
        }
    }
}
