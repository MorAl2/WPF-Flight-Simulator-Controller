﻿using GUI_Flight_Simulator_Controller.controlers;
using System;
using System.Configuration;
using System.Windows;

namespace GUI_Flight_Simulator_Controller
{
    public partial class MainWindow : Window
    {
        ConnectViewModel disconnectVM;
        public MainWindow()
        {           
            InitializeComponent();
            this.ConnectV.Visibility = Visibility.Visible;
            WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            try
            {
                this.disconnectVM = (Application.Current as App).ConnectVM;
            }
            catch(Exception)
            {

            }
        }
        // closing the program when closed.
        private void Window_Closed(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }
        // disconnect button
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            disconnectVM.VMDisconnect();
        }
        // exit button
        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.disconnectVM.VMDisconnect();
            Environment.Exit(0);
        }
    }
}
