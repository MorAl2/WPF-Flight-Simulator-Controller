﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace GUI_Flight_Simulator_Controller.controlers
{
    public partial class DashBoard : UserControl
    {
        private DashViewModel dashViewModel;
        public DashBoard()
        {
            InitializeComponent();
            try
            {
                dashViewModel = ((App)Application.Current).DashVM;
                DataContext = dashViewModel;
            }
            catch(Exception)
            {

            }
        }
        // creating the view model and biniding data.
        public void StartUpdate()
        {
            dashViewModel.UpdateData();
        }
    }
}
