﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI_Flight_Simulator_Controller.controlers
{
    /// <summary>
    /// Interaction logic for Joystick.xaml
    /// </summary>
    public partial class Joystick : UserControl
    {
        private Point centerPoint;
        private volatile bool mousePressed;
        private double end_x, end_y, lenXknob, lenYknob, distance, ellipseRadius;
        DoubleAnimation x, y;
        Storyboard storyboard;
        /* constructor of Joystick
         * Initialize variables
         */
        public Joystick()
        {
            InitializeComponent();
            centerPoint = new Point(Base.Width / 2, Base.Height / 2);
            mousePressed = false;
            ellipseRadius = this.KnobBase.Width / 2;
            storyboard = Knob.Resources["CenterKnob"] as Storyboard;
            x = storyboard.Children[0] as DoubleAnimation;
            y = storyboard.Children[1] as DoubleAnimation;
            x.From = 0;
            y.From = 0;
        }
        /*
         * define DependencyProperty for property Joystick X and Y - binding to VM
         */
        public static readonly DependencyProperty JoysitckXProperty = DependencyProperty.Register("JoysitckX", typeof(Double), typeof(Joystick));
        public static readonly DependencyProperty JoysitckYProperty = DependencyProperty.Register("JoysitckY", typeof(Double), typeof(Joystick));
        public double JoysitckX
        {
            get
            { return (double)GetValue(JoysitckXProperty); }
            set
            {
                SetValue(JoysitckXProperty, Math.Round(value, 3));
            }
        }
        public double JoysitckY
        {
            get
            { return (double)GetValue(JoysitckYProperty); }
            set
            {
                SetValue(JoysitckYProperty, Math.Round(value, 3));
            }
        }
        /*
         * event of click on knob - begin CaptureMouse 
         */
        private void Knob_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            mousePressed = true;
            (this.Knob).CaptureMouse();
        }
        /*
         * event of mouse move on Base 
         */
        private void Base_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousePressed)
            {
                // get position of x and y 
                end_x = Mouse.GetPosition(this.Base).X;
                end_y = Mouse.GetPosition(this.Base).Y;
                // calculate distance between currect point to center 
                lenXknob = end_x - centerPoint.X;
                lenYknob = end_y - centerPoint.Y;
                distance = Math.Sqrt((lenXknob * lenXknob) + (lenYknob * lenYknob));
                // check limitations of knob 
                if (distance <= (Base.Width / 4))
                {
                    x.To = lenXknob;
                    y.To = lenYknob;
                    storyboard.Begin();
                    x.From = x.To;
                    y.From = y.To;
                    JoysitckX = lenXknob/((this.Base.Width/4)-1);
                    JoysitckY = lenYknob * (-1)/ ((this.Base.Width / 4) - 1);
                }
            }
        }
        /*
         * event of mouse up on knob 
         * ReleaseMouseCapture 
         * play storyboard
         */
        private void Knob_MouseUp(object sender, MouseButtonEventArgs e)
        {
            (this.Knob).ReleaseMouseCapture();
            mousePressed = false;
            JoysitckX = 0;
            JoysitckY = 0;
            x.To = 0;
            y.To = 0;
            storyboard.Begin();
        }
    }
}
