﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace GUI_Flight_Simulator_Controller.controlers
{
    public partial class MapView : UserControl
    {
        private MapViewModel mapViewModel;

        public MapView()
        {
            InitializeComponent();
            try
            {
                mapViewModel = ((App)Application.Current).MapVM;
            }
            catch(Exception)
            {

            }
            
            DataContext = mapViewModel;
        }

        // creating the view model and biniding data.
        public void SetSingelMod(Model m)
        {
            mapViewModel = new MapViewModel(m);
            DataContext = mapViewModel;
            // updating the plane location.
            mapViewModel.UpdateData();
        }
        public void StartUpdate()
        {
            mapViewModel.UpdateData();
        }

        private void Zoom_Click(object sender, RoutedEventArgs e)
        {
            myMap.ZoomLevel = 1;
        }

        private void Center_Click(object sender, RoutedEventArgs e)
        {
            myMap.Center = new Microsoft.Maps.MapControl.WPF.Location(23.395997, 30.755984);
        }
    }
}
