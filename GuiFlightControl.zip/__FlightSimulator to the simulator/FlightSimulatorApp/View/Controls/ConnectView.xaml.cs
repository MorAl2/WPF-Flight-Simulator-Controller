﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI_Flight_Simulator_Controller.controlers
{

    public partial class ConnectView : UserControl
    {
        // the Control view model.
        private ConnectViewModel connectViewModel;
        //CTOR
        public ConnectView()
        {
            InitializeComponent();
            IPTextBox.Text = ConfigurationManager.AppSettings["IP"];
            PortTextBox.Text = ConfigurationManager.AppSettings["Port"];
            try
            {
                connectViewModel = (Application.Current as App).ConnectVM;
                DataContext = connectViewModel;
            }
            catch (Exception)
            {

            }
        }
        // connecting to the simulator.
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try {
                this.InvalidData.Content = "";
                int port = int.Parse(PortTextBox.Text);
                connectViewModel.VMConnect(IPTextBox.Text,port);
            }
            catch(Exception)
            {
                this.InvalidData.Content = "Invalid Ip Or Port Supplied";
            }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.connectViewModel.VMDisconnect();
            Environment.Exit(0);
        }
    }
}
