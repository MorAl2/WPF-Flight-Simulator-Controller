﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GUI_Flight_Simulator_Controller.controlers
{
    /// <summary>
    /// Interaction logic for MyJoystick.xaml
    /// </summary>
    public partial class MyJoystick : UserControl
    {
        JoystickViewModel vm;
        /* constructor of MyJoystick
        * Initialize variables
        */
        public MyJoystick()
        {
            InitializeComponent();
            try
            {
                vm = (Application.Current as App).JoyStickVM;
                DataContext = vm;
                Console.WriteLine("Succsess");
            }
            catch
            {
                Console.WriteLine("Failes");
            }
        }
    }
}
