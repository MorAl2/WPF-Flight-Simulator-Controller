﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_Flight_Simulator_Controller.controlers
{
    public class ConnectViewModel : INotifyPropertyChanged
    {
        private Model model;
        public ConnectViewModel(Model m)
        {
            this.model = m;
            // joining the observers list.
            this.model.PropertyChanged += delegate (Object sender, PropertyChangedEventArgs e)
            {
                OnPropertyChanged(e.PropertyName);
            };
        }

        public System.Windows.Visibility ConnectedSign { get { return model.ConnectedSign; } }

        public System.Windows.Visibility BadConnect { get { return model.BadConnect; } }

        // the observers list.
        public event PropertyChangedEventHandler PropertyChanged;

        // updating the observers.
        public void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
        // disconnecting
        internal void VMDisconnect()
        {
            model.Disconnect();
        }

        // telling the model to Connect to the simulator.
        public void VMConnect(string ip, int port) {
            model.Connect(ip, port);
        }

    }
}
