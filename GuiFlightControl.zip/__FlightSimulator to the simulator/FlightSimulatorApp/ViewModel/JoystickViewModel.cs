﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_Flight_Simulator_Controller.controlers
{
    public class JoystickViewModel 
    {
        private Model model;
        public JoystickViewModel(Model model)
        {
            this.model = model;
        }
        private double throttle=0;
        private double aileron = 0;
        private double rudder=0;
        private double elevator=0;
        public double VM_Throttle
        {
            get { return throttle; }
            set
            {
                // check if change is greater that 0.0.2
                if (Math.Abs(throttle - value) >= 0.02)
                {
                    throttle = value;
                    //change value in the model
                    model.MoveThrottle(throttle);
                }
            }
        }
        public double VM_Aileron
        {
            get { return aileron; }
            set
            {
                // check if change is greater that 0.0.2
                if (Math.Abs(aileron - value) >= 0.02)
                {
                    aileron = value;
                    //change value in the model
                    model.MoveAileron(aileron);
                }  
            }
        }
        public double VM_JoysitckX
        {
            get { return rudder; }
            set
            {
                // check if change is greater that 0.0.2
                if (Math.Abs(rudder - value) >= 0.02)
                {
                    rudder = value;
                    //change value in the model
                    model.MoveJoystickX(rudder);
                }
            }
        }
        public double VM_JoysitckY
        {
            get { return elevator; }
            set
            {
                // check if change is greater that 0.0.2
                if (Math.Abs(elevator - value) >= 0.02)
                {
                    elevator = value;
                    //change value in the model
                    model.MoveJoystickY(elevator);
                }
            }
        }
        // updating the data from the model.
        public void UpdateData()
        {
            model.UpdateControllerScreen();
        }
    }
}
    

