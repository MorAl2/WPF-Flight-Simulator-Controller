﻿using GUI_Flight_Simulator_Controller.controlers;
using System.Windows;

namespace GUI_Flight_Simulator_Controller
{
    public partial class App : Application
    {

        public Model ModelObj { get; internal set;}
        public ConnectViewModel ConnectVM { get; internal set; }
        public DashViewModel DashVM { get; internal set; }
        public MapViewModel MapVM { get; internal set; }
        public JoystickViewModel JoyStickVM { get; internal set; }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            ModelObj = new Model();
            ConnectVM = new ConnectViewModel(this.ModelObj);
            DashVM = new DashViewModel(this.ModelObj);
            MapVM = new MapViewModel(this.ModelObj);
            JoyStickVM = new JoystickViewModel(this.ModelObj);
        }
    }
}